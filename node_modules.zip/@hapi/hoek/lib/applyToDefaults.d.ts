import { applyToDefaults } from "./index";

export = applyToDefaults;
