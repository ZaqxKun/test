import { assert } from "./index";

export = assert;
