import { AssertError } from "./index";

export = AssertError;
