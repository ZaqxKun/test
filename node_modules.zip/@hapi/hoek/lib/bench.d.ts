import { Bench } from "./index";

export = Bench;
