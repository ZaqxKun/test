import { block } from "./index";

export = block;
