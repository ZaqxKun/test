import { contain } from "./index";

export = contain;
