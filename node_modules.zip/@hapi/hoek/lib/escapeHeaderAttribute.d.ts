import { escapeHeaderAttribute } from "./index";

export = escapeHeaderAttribute;
