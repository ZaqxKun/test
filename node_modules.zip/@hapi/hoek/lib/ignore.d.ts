import { ignore } from "./index";

export = ignore;
