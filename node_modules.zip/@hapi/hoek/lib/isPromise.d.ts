import { isPromise } from "./index";

export = isPromise;
