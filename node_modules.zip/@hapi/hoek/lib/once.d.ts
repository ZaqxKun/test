import { once } from "./index";

export = once;
