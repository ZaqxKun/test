export default `flf2a$ 4 4 18 16 2
4max.flf by Philip Menke (philippe@dds.nl)
April 1995
$  $#
$  $#
$  $#
$  $##
d8b$#
Y8P$#
\`"'$#
(8)$##
o8o o8o$#
\`"' \`"'$#
       $#
       $##
__88_88__$#
""88"88""$#
__88_88__$#
""88"88""$##
.dPIIY8$#
\`YbII "$#
o.\`II8b$#
8boIIP'$##
.o. dP $#
\`"'dP  $#
  dP.o.$#
 dP \`"'$##
 d888    $#
dP_______$#
Yb"""88""$#
\`Ybo 88  $##
 .o.$#
,dP'$#
    $#
    $##
 dP$#
dP $#
Yb $#
 Yb$##
Yb $#
 Yb$#
 dP$#
dP $##
   o   $#
\`8.8.8'$#
.8.8.8.$#
   "   $##
   oo   $#
___88___$#
"""88"""$#
   ""   $##
    $#
    $#
 .o.$#
,dP'$##
        $#
________$#
""""""""$#
        $##
   $#
   $#
.o.$#
\`"'$##
   dP$#
  dP $#
 dP  $#
dP   $##
 dP"Yb $#
dP   Yb$#
Yb   dP$#
 YbodP $##
  .d$#
.d88$#
  88$#
  88$##
oP"Yb.$#
"' dP'$#
  dP' $#
.d8888$##
88888$#
  .dP$#
o \`Yb$#
YbodP$##
  dP88 $#
 dP 88 $#
d888888$#
    88 $##
888888$#
88oo."$#
   \`8b$#
8888P'$##
  dP'  $#
.d8'   $#
8P"""Yb$#
\`YboodP$##
888888P$#
    dP $#
   dP  $#
  dP   $##
.dP"o.$#
\`8b.d'$#
d'\`Y8b$#
\`bodP'$##
dP""Yb$#
Ybood8$#
  .8P'$#
 .dP' $##
.o.$#
\`"'$#
.o.$#
\`"'$##
 .o.$#
 \`"'$#
 .o.$#
,dP'$##
  .dP'$#
.dP'  $#
\`Yb.  $#
  \`Yb.$##
      $#
oooooo$#
______$#
""""""$##
\`Yb.  $#
  \`Yb.$#
  .dP'$#
.dP'  $##
oP"Yb.$#
"'.dP'$#
  8P  $#
 (8)  $##
 dP""Yb $#
dP PY Yb$#
Yb boodP$#
 Ybooo  $##
   db   $#
  dPYb  $#
 dP__Yb $#
dP""""Yb$##
88""Yb$#
88__dP$#
88""Yb$#
88oodP$##
 dP""b8$#
dP   \`"$#
Yb     $#
 YboodP$##
8888b. $#
 8I  Yb$#
 8I  dY$#
8888Y" $##
888888$#
88__  $#
88""  $#
888888$##
888888$#
88__  $#
88""  $#
88    $##
 dP""b8$#
dP   \`"$#
Yb  "88$#
 YboodP$##
88  88$#
88  88$#
888888$#
88  88$##
88$#
88$#
88$#
88$##
 88888$#
    88$#
o.  88$#
"bodP'$##
88  dP$#
88odP $#
88"Yb $#
88  Yb$##
88    $#
88    $#
88  .o$#
88ood8$##
8b    d8$#
88b  d88$#
88YbdP88$#
88 YY 88$##
88b 88$#
88Yb88$#
88 Y88$#
88  Y8$##
 dP"Yb $#
dP   Yb$#
Yb   dP$#
 YbodP $##
88""Yb$#
88__dP$#
88""" $#
88    $##
 dP"Yb $#
dP   Yb$#
Yb b dP$#
 \`"YoYo$##
88""Yb$#
88__dP$#
88"Yb $#
88  Yb$##
.dP"Y8$#
\`Ybo."$#
o.\`Y8b$#
8bodP'$##
888888$#
  88  $#
  88  $#
  88  $##
88   88$#
88   88$#
Y8   8P$#
\`YbodP'$##
Yb    dP$#
 Yb  dP $#
  YbdP  $#
   YP   $##
Yb        dP$#
 Yb  db  dP $#
  YbdPYbdP  $#
   YP  YP   $##
Yb  dP$#
 YbdP $#
 dPYb $#
dP  Yb$##
Yb  dP$#
 YbdP $#
  8P  $#
 dP   $##
8888P$#
  dP $#
 dP  $#
d8888$##
88888$#
88   $#
88   $#
88888$##
Yb   $#
 Yb  $#
  Yb $#
   Yb$##
88888$#
   88$#
   88$#
88888$##
  .db.  $#
.dP'\`Yb.$#
        $#
        $##
          $#
          $#
          $#
oooooooooo$##
.o. $#
\`Yb.$#
    $#
    $##
   db   $#
  dPYb  $#
 dP__Yb $#
dP""""Yb$##
88""Yb$#
88__dP$#
88""Yb$#
88oodP$##
 dP""b8$#
dP   \`"$#
Yb     $#
 YboodP$##
8888b. $#
 8I  Yb$#
 8I  dY$#
8888Y" $##
888888$#
88__  $#
88""  $#
888888$##
888888$#
88__  $#
88""  $#
88    $##
 dP""b8$#
dP   \`"$#
Yb  "88$#
 YboodP$##
88  88$#
88  88$#
888888$#
88  88$##
88$#
88$#
88$#
88$##
 88888$#
    88$#
o.  88$#
"bodP'$##
88  dP$#
88odP $#
88"Yb $#
88  Yb$##
88    $#
88    $#
88  .o$#
88ood8$##
8b    d8$#
88b  d88$#
88YbdP88$#
88 YY 88$##
88b 88$#
88Yb88$#
88 Y88$#
88  Y8$##
 dP"Yb $#
dP   Yb$#
Yb   dP$#
 YbodP $##
88""Yb$#
88__dP$#
88""" $#
88    $##
 dP"Yb $#
dP   Yb$#
Yb b dP$#
 \`"YoYo$##
88""Yb$#
88__dP$#
88"Yb $#
88  Yb$##
.dP"Y8$#
\`Ybo."$#
o.\`Y8b$#
8bodP'$##
888888$#
  88  $#
  88  $#
  88  $##
88   88$#
88   88$#
Y8   8P$#
\`YbodP'$##
Yb    dP$#
 Yb  dP $#
  YbdP  $#
   YP   $##
Yb        dP$#
 Yb  db  dP $#
  YbdPYbdP  $#
   YP  YP   $##
Yb  dP$#
 YbdP $#
 dPYb $#
dP  Yb$##
Yb  dP$#
 YbdP $#
  8P  $#
 dP   $##
8888P$#
  dP $#
 dP  $#
d8888$##
  d888$#
.dP   $#
\`Yb   $#
  Y888$##
II$#
II$#
II$#
II$##
888b  $#
   Yb.$#
   dP'$#
888P  $##
 dP"Yb  dP$#
dP  \`YbdP $#
          $#
          $##
db db db$#
""dPYb""$#
 dP__Yb $#
dP""""Yb$##
 db  db $#
 ".oo." $#
 dP  Yb $#
 YboodP $##
db   db$#
""   ""$#
Yb   dP$#
 YbodP $##
db db db$#
""dPYb""$#
 dP__Yb $#
dP""""Yb$##
 db  db $#
 ".oo." $#
 dP  Yb $#
 YboodP $##
db   db$#
""   ""$#
Y8   8P$#
 YbodP $##
 dP"o.$#
 88.d'$#
 88\`8b$#
d8P P'$##
`