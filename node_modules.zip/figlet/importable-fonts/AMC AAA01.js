export default `flf2a$ 15 14 18 -1 18

                AMC Alt.Ascii-Art font by LESTER
                ================================


-> Conversion to FigLet font by MEPH. (Part of ASCII Editor Service Pack I)
   (http://studenten.freepage.de/meph/ascii/ascii/editor/_index.htm)
-> Defined: ASCII code alphabet
-> Uppercase characters only.

     .-~~-.
    (_^..^_)
Lester||||AMC - Anthony Cucchiara
*Mythos Online : Internet Magazine of Lovecraftian Horror - Dead Alice*
http://www.fortunecity.com/victorian/redlion/157/deadal.htm
*Visit my web page ANSI/ASCII/Fonts*
http://members.aol.com/lester5374/

     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
      @
      @
      @
      @
      @
      @
      @
      @
      @
      @
      @
 SS   @
S%%S  @
 SS   @
      @@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
 .S_SSSs    @
.SS~SSSSS   @
S%S   SSSS  @
S%S    S%S  @
S%S SSSS%S  @
S&S  SSS%S  @
S&S    S&S  @
S&S    S&S  @
S*S    S&S  @
S*S    S*S  @
S*S    S*S  @
SSS    S*S  @
       SP   @
       Y    @
            @@
 .S_SSSs    @
.SS~SSSSS   @
S%S   SSSS  @
S%S    S%S  @
S%S SSSS%P  @
S&S  SSSY   @
S&S    S&S  @
S&S    S&S  @
S*S    S&S  @
S*S    S*S  @
S*S SSSSP   @
S*S  SSY    @
SP          @
Y           @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S     @
S&S     @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    S&S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*S    d*S  @
S*S   .S*S  @
S*S_sdSSS   @
SSS~YSSY    @
            @
            @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S_Ss  @
S&S~SP  @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S_Ss  @
S&S~SP  @
S&S     @
S*b     @
S*S     @
S*S     @
S*S     @
SP      @
Y       @
        @@
  sSSSSs  @
 d%%%%SP  @
d%S'      @
S%S       @
S&S       @
S&S       @
S&S       @
S&S sSSs  @
S*b \`S%%  @
S*S   S%  @
 SS_sSSS  @
  Y~YSSY  @
          @
          @
          @@
 .S    S.   @
.SS    SS.  @
S%S    S%S  @
S%S    S%S  @
S%S SSSS%S  @
S&S  SSS&S  @
S&S    S&S  @
S&S    S&S  @
S*S    S*S  @
S*S    S*S  @
S*S    S*S  @
SSS    S*S  @
       SP   @
       Y    @
            @@
 .S  @
.SS  @
S%S  @
S%S  @
S&S  @
S&S  @
S&S  @
S&S  @
S*S  @
S*S  @
S*S  @
S*S  @
SP   @
Y    @
     @@
    .S  @
   .SS  @
   S%S  @
   S%S  @
   S&S  @
   S&S  @
   S&S  @
   S&S  @
   d*S  @
  .S*S  @
sdSSS   @
YSSY    @
        @
        @
        @@
 .S    S.   @
.SS    SS.  @
S%S    S&S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSSY%b  @
S&S    \`S%  @
S*S     S%  @
S*S     S&  @
S*S     S&  @
S*S     SS  @
SP          @
Y           @
            @@
S.      @
SS.     @
S%S     @
S%S     @
S&S     @
S&S     @
S&S     @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
 .S_SsS_S.   @
.SS~S*S~SS.  @
S%S \`Y' S%S  @
S%S     S%S  @
S%S     S%S  @
S&S     S&S  @
S&S     S&S  @
S&S     S&S  @
S*S     S*S  @
S*S     S*S  @
S*S     S*S  @
SSS     S*S  @
        SP   @
        Y    @
             @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    S&S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*S    S*S  @
S*S    S*S  @
S*S    S*S  @
S*S    SSS  @
SP          @
Y           @
            @@
  sSSs_sSSs    @
 d%%SP~YS%%b   @
d%S'     \`S%b  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSS   @
  YSSP~YSSY    @
               @
               @
               @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSSY    @
S*S         @
S*S         @
S*S         @
S*S         @
SP          @
Y           @
            @@
  sSSs_sSSs    @
 d%%SP~YS%%b   @
d%S'     \`S%b  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSSS  @
  YSSP~YSSSSS  @
               @
               @
               @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSY%b   @
S*S   \`S%b  @
S*S    S%S  @
S*S    S&S  @
S*S    SSS  @
SP          @
Y           @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%|     @
S&S     @
Y&Ss    @
\`S&&S   @
  \`S*S  @
   l*S  @
  .S*P  @
sSS*S   @
YSS'    @
        @
        @
        @@
sdSS_SSSSSSbs  @
YSSS~S%SSSSSP  @
     S%S       @
     S%S       @
     S&S       @
     S&S       @
     S&S       @
     S&S       @
     S*S       @
     S*S       @
     S*S       @
     S*S       @
     SP        @
     Y         @
               @@
 .S       S.   @
.SS       SS.  @
S%S       S%S  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSS   @
  YSSP~YSSY    @
               @
               @
               @@
 .S    S.   @
.SS    SS.  @
S%S    S%S  @
S%S    S%S  @
S&S    S%S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*b    S*S  @
S*S.   S*S  @
 SSSbs_S*S  @
  YSSP~SSS  @
            @
            @
            @@
 .S     S.   @
.SS     SS.  @
S%S     S%S  @
S%S     S%S  @
S%S     S%S  @
S&S     S&S  @
S&S     S&S  @
S&S     S&S  @
S*S     S*S  @
S*S  .  S*S  @
S*S_sSs_S*S  @
SSS~SSS~S*S  @
             @
             @
             @@
 .S S.   @
.SS SS.  @
S%S S%S  @
S%S S%S  @
S%S S%S  @
 SS SS   @
  S_S    @
 SS~SS   @
S*S S*S  @
S*S S*S  @
S*S S*S  @
S*S S*S  @
SP       @
Y        @
         @@
 .S S.   @
.SS SS.  @
S%S S%S  @
S%S S%S  @
S%S S%S  @
 SS SS   @
  S S    @
  SSS    @
  S*S    @
  S*S    @
  S*S    @
  S*S    @
  SP     @
  Y      @
         @@
 sdSSSSSSSbs  @
 YSSSSSSSS%S  @
        S%S   @
       S&S    @
      S&S     @
      S&S     @
     S&S      @
    S*S       @
   S*S        @
 .s*S         @
 sY*SSSSSSSP  @
sY*SSSSSSSSP  @
              @
              @
              @@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
 .S_SSSs    @
.SS~SSSSS   @
S%S   SSSS  @
S%S    S%S  @
S%S SSSS%S  @
S&S  SSS%S  @
S&S    S&S  @
S&S    S&S  @
S*S    S&S  @
S*S    S*S  @
S*S    S*S  @
SSS    S*S  @
       SP   @
       Y    @
            @@
 .S_SSSs    @
.SS~SSSSS   @
S%S   SSSS  @
S%S    S%S  @
S%S SSSS%P  @
S&S  SSSY   @
S&S    S&S  @
S&S    S&S  @
S*S    S&S  @
S*S    S*S  @
S*S SSSSP   @
S*S  SSY    @
SP          @
Y           @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S     @
S&S     @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    S&S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*S    d*S  @
S*S   .S*S  @
S*S_sdSSS   @
SSS~YSSY    @
            @
            @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S_Ss  @
S&S~SP  @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
  sSSs  @
 d%%SP  @
d%S'    @
S%S     @
S&S     @
S&S_Ss  @
S&S~SP  @
S&S     @
S*b     @
S*S     @
S*S     @
S*S     @
SP      @
Y       @
        @@
  sSSSSs  @
 d%%%%SP  @
d%S'      @
S%S       @
S&S       @
S&S       @
S&S       @
S&S sSSs  @
S*b \`S%%  @
S*S   S%  @
 SS_sSSS  @
  Y~YSSY  @
          @
          @
          @@
 .S    S.   @
.SS    SS.  @
S%S    S%S  @
S%S    S%S  @
S%S SSSS%S  @
S&S  SSS&S  @
S&S    S&S  @
S&S    S&S  @
S*S    S*S  @
S*S    S*S  @
S*S    S*S  @
SSS    S*S  @
       SP   @
       Y    @
            @@
 .S  @
.SS  @
S%S  @
S%S  @
S&S  @
S&S  @
S&S  @
S&S  @
S*S  @
S*S  @
S*S  @
S*S  @
SP   @
Y    @
     @@
    .S  @
   .SS  @
   S%S  @
   S%S  @
   S&S  @
   S&S  @
   S&S  @
   S&S  @
   d*S  @
  .S*S  @
sdSSS   @
YSSY    @
        @
        @
        @@
 .S    S.   @
.SS    SS.  @
S%S    S&S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSSY%b  @
S&S    \`S%  @
S*S     S%  @
S*S     S&  @
S*S     S&  @
S*S     SS  @
SP          @
Y           @
            @@
S.      @
SS.     @
S%S     @
S%S     @
S&S     @
S&S     @
S&S     @
S&S     @
S*b     @
S*S.    @
 SSSbs  @
  YSSP  @
        @
        @
        @@
 .S_SsS_S.   @
.SS~S*S~SS.  @
S%S \`Y' S%S  @
S%S     S%S  @
S%S     S%S  @
S&S     S&S  @
S&S     S&S  @
S&S     S&S  @
S*S     S*S  @
S*S     S*S  @
S*S     S*S  @
SSS     S*S  @
        SP   @
        Y    @
             @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    S&S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*S    S*S  @
S*S    S*S  @
S*S    S*S  @
S*S    SSS  @
SP          @
Y           @
            @@
  sSSs_sSSs    @
 d%%SP~YS%%b   @
d%S'     \`S%b  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSS   @
  YSSP~YSSY    @
               @
               @
               @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSSY    @
S*S         @
S*S         @
S*S         @
S*S         @
SP          @
Y           @
            @@
  sSSs_sSSs    @
 d%%SP~YS%%b   @
d%S'     \`S%b  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSSS  @
  YSSP~YSSSSS  @
               @
               @
               @@
 .S_sSSs    @
.SS~YS%%b   @
S%S   \`S%b  @
S%S    S%S  @
S%S    d*S  @
S&S   .S*S  @
S&S_sdSSS   @
S&S~YSY%b   @
S*S   \`S%b  @
S*S    S%S  @
S*S    S&S  @
S*S    SSS  @
SP          @
Y           @
            @@
  sSSs  @
 d%%SP  @
d%S'    @
S%|     @
S&S     @
Y&Ss    @
\`S&&S   @
  \`S*S  @
   l*S  @
  .S*P  @
sSS*S   @
YSS'    @
        @
        @
        @@
sdSS_SSSSSSbs  @
YSSS~S%SSSSSP  @
     S%S       @
     S%S       @
     S&S       @
     S&S       @
     S&S       @
     S&S       @
     S*S       @
     S*S       @
     S*S       @
     S*S       @
     SP        @
     Y         @
               @@
 .S       S.   @
.SS       SS.  @
S%S       S%S  @
S%S       S%S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S&S       S&S  @
S*b       d*S  @
S*S.     .S*S  @
 SSSbs_sdSSS   @
  YSSP~YSSY    @
               @
               @
               @@
 .S    S.   @
.SS    SS.  @
S%S    S%S  @
S%S    S%S  @
S&S    S%S  @
S&S    S&S  @
S&S    S&S  @
S&S    S&S  @
S*b    S*S  @
S*S.   S*S  @
 SSSbs_S*S  @
  YSSP~SSS  @
            @
            @
            @@
 .S     S.   @
.SS     SS.  @
S%S     S%S  @
S%S     S%S  @
S%S     S%S  @
S&S     S&S  @
S&S     S&S  @
S&S     S&S  @
S*S     S*S  @
S*S  .  S*S  @
S*S_sSs_S*S  @
SSS~SSS~S*S  @
             @
             @
             @@
 .S S.   @
.SS SS.  @
S%S S%S  @
S%S S%S  @
S%S S%S  @
 SS SS   @
  S_S    @
 SS~SS   @
S*S S*S  @
S*S S*S  @
S*S S*S  @
S*S S*S  @
SP       @
Y        @
         @@
 .S S.   @
.SS SS.  @
S%S S%S  @
S%S S%S  @
S%S S%S  @
 SS SS   @
  S S    @
  SSS    @
  S*S    @
  S*S    @
  S*S    @
  S*S    @
  SP     @
  Y      @
         @@
 sdSSSSSSSbs  @
 YSSSSSSSS%S  @
        S%S   @
       S&S    @
      S&S     @
      S&S     @
     S&S      @
    S*S       @
   S*S        @
 .s*S         @
 sY*SSSSSSSP  @
sY*SSSSSSSSP  @
              @
              @
              @@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@
@
@
@
@@
`