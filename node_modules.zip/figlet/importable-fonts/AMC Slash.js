export default `flf2a$ 10 9 14 -1 18

                   AMCslash font by LESTER
                 =============================


-> Conversion to FigLet font by MEPH. (Part of ASCII Editor Service Pack I)
   (http://studenten.freepage.de/meph/ascii/ascii/editor/_index.htm)
-> Defined: ASCII code alphabet


     .-~~-.
    (_^..^_)
Lester||||AMC - Anthony Cucchiara
*Mythos Online : Internet Magazine of Lovecraftian Horror - Dead Alice*
http://www.fortunecity.com/victorian/redlion/157/deadal.htm
*Visit my web page ANSI/ASCII/Fonts*
http://members.aol.com/lester5374/

   $@
   $@
   $@
   $@
    @
    @
    @
    @
    @
    @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
     @
     @
     @
     @
     @
     @
 SS  @
S%%S @
 SS  @
     @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SSSs. S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS .sSSS  @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
SS        @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
;;;;;;;:' @
          @@
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
SSSs.     @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
.s5SSSs. @
         @
sS       @
SS       @
SSSs.    @
SS       @
SS       @
SS       @
:;       @
         @@
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
SS        @
SS        @
SS   \`\`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
SSSs. S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
s.  @
SS. @
S%S @
S%S @
S%S @
S%S @
\`:; @
;,. @
;:' @
    @@
      s.  @
      SS. @
      S%S @
      S%S @
      S%S @
      S%S @
      \`:; @
.,;   ;,. @
\`:;;;;;:' @
          @@
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
SSSSs.S:' @
SS  "SS.  @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
.s        @
          @
sS        @
SS        @
SS        @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
.s5ssSs.  @
   SS SS. @
sS SS S%S @
SS :; S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
.s    s.  @
      SS. @
sSs.  S%S @
SS\`S. S%S @
SS \`S.S%S @
SS  \`sS%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS .sS::' @
SS        @
SS        @
SS        @
\`:        @
          @@
.s5SSs.  @
     SS. @
sS   S%S @
SS   S%S @
SS   S%S @
SS   S%S @
SS   \`:; @
SS  \`;,. @
\`:;;;;;; @
         @@
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS .sS;:' @
SS    ;,  @
SS    \`:; @
SS    ;,. @
\`:    ;:' @
          @@
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
\`:;;;;.   @
      ;;. @
      \`:; @
.,;   ;,. @
\`:;;;;;:' @
          @@
.s5SSSSs. @
   SSS    @
   S%S    @
   S%S    @
   S%S    @
   S%S    @
   \`:;    @
   ;,.    @
   ;:'    @
          @@
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
 SS   S%S @
 SS   \`:; @
  SS  ;,. @
   \`:;;:' @
          @@
.s s.  s.  @
   SS. SS. @
sS S%S S%S @
SS S%S S%S @
SS S%S S%S @
SS S%S S%S @
SS \`:; \`:; @
SS ;,. ;,. @
\`:;;:'\`::' @
           @@
.s5 s.  @
    SS. @
ssS SSS @
SSS SSS @
 SSSSS  @
SSS SSS @
SSS \`:; @
SSS ;,. @
\`:; ;:' @
        @@
.s5 s.  @
    SS. @
ssS SSS @
SSS SSS @
 SSSSS  @
  SSS   @
  \`:;   @
  ;,.   @
  ;:'   @
        @@
.s5SSSSs. @
      SSS @
     sSS  @
    sSS   @
   sSS    @
  sSS     @
 sSS      @
sSS       @
\`:;;;;;:' @
          @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SSSs. S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SS .sSSS  @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
;;;;;;;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    \`:; @
SSSs.     @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
         @
.s5SSSs. @
         @
sS       @
SSSs.    @
SS       @
SS       @
SS       @
:;       @
         @@
          @
.s5SSSs.  @
      SS. @
sS    \`:; @
SS        @
SS        @
SS   \`\`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s    s.  @
      SS. @
sS    S%S @
SSSs. S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
    @
s.  @
SS. @
S%S @
S%S @
S%S @
\`:; @
;,. @
;:' @
    @@
          @
      s.  @
      SS. @
      S%S @
      S%S @
      S%S @
      \`:; @
.,;   ;,. @
\`:;;;;;:' @
          @@
          @
.s    s.  @
      SS. @
sS    S%S @
SSSSs.S:' @
SS  "SS.  @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
          @
.s        @
          @
sS        @
SS        @
SS        @
SS        @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s5ssSs.  @
   SS SS. @
sS SS S%S @
SS :; S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
          @
.s    s.  @
      SS. @
sSs.  S%S @
SS \`S.S%S @
SS  \`sS%S @
SS    \`:; @
SS    ;,. @
:;    ;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SS .sS::' @
SS        @
SS        @
SS        @
\`:        @
          @@
          @
.s5SSs.   @
     SS.  @
sS   S%S  @
SS   S%S  @
SS   S%S  @
SS   \`:;  @
SS  \`;,.  @
\`:;;;;;;, @
          @@
          @
.s5SSSs.  @
      SS. @
sS    S%S @
SS .sS;:' @
SS    ;,  @
SS    \`:; @
SS    ;,. @
\`:    ;:' @
          @@
          @
.s5SSSs.  @
      SS. @
sS    \`:; @
\`:;;;;.   @
      ;;. @
      \`:; @
.,;   ;,. @
\`:;;;;;:' @
          @@
          @
.s5SSSSs. @
   SSS    @
   S%S    @
   S%S    @
   S%S    @
   \`:;    @
   ;,.    @
   ;:'    @
          @@
          @
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
SS    S%S @
SS    \`:; @
SS    ;,. @
\`:;;;;;:' @
          @@
          @
.s    s.  @
      SS. @
sS    S%S @
SS    S%S @
 SS   S%S @
 SS   \`:; @
  SS  ;,. @
   \`:;;:' @
          @@
           @
.s s.  s.  @
   SS. SS. @
sS S%S S%S @
SS S%S S%S @
SS S%S S%S @
SS \`:; \`:; @
SS ;,. ;,. @
\`:;;:'\`::' @
           @@
        @
.s5 s.  @
    SS. @
ssS SSS @
 SSSSS  @
SSS SSS @
SSS \`:; @
SSS ;,. @
\`:; ;:' @
        @@
        @
.s5 s.  @
    SS. @
ssS SSS @
 SSSSS  @
  SSS   @
  \`:;   @
  ;,.   @
  ;:'   @
        @@
          @
.s5SSSSs. @
      SSS @
    sSSS  @
   sSS"   @
  sSS     @
 sSS      @
sSS       @
\`:;;;;;:' @
          @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
`