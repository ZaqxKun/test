export default `flf2a$ 8 7 13 -1 18

                   AMCtubes font by LESTER
                 =============================


-> Conversion to FigLet font by MEPH. (Part of ASCII Editor Service Pack I)
   (http://studenten.freepage.de/meph/ascii/ascii/editor/_index.htm)
-> Defined: ASCII code alphabet
-> Uppercase characters only.

     .-~~-.
    (_^..^_)
Lester||||AMC - Anthony Cucchiara
*Mythos Online : Internet Magazine of Lovecraftian Horror - Dead Alice*
http://www.fortunecity.com/victorian/redlion/157/deadal.htm
*Visit my web page ANSI/ASCII/Fonts*
http://members.aol.com/lester5374/

    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
     @
     @
     @
     @
.ss  @
SSSz @
'ZZ' @
     @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
d s.   @
S  ~O  @
S   \`b @
S sSSO @
S    O @
S    O @
P    P @
       @@
d ss.  @
S    b @
S    P @
S sSS' @
S    b @
S    P @
P \`SS  @
       @@
  sSSs. @
 S      @
S       @
S       @
S       @
 S      @
  "sss' @
        @@
d ss    @
S   ~o  @
S     b @
S     S @
S     P @
S    S  @
P ss"   @
        @@
d sss   @
S       @
S       @
S sSSs  @
S       @
S       @
P sSSss @
        @@
d sss  @
S      @
S      @
S sSSs @
S      @
S      @
P      @
       @@
  sSSSs   @
 S     S  @
S         @
S         @
S    ssSb @
 S     S  @
  "sss"   @
          @@
d    d @
S    S @
S    S @
S sSSS @
S    S @
S    S @
P    P @
       @@
d @
S @
S @
S @
S @
S @
P @
  @@
        d @
        S @
        S @
        S @
d       P @
 S     S  @
  "sss"   @
          @@
d     S @
S    P  @
Ssss'   @
S   s   @
S    b  @
S     b @
P     P @
        @@
d      @
S      @
S      @
S      @
S      @
S      @
P sSSs @
       @@
d s   sb @
S  S S S @
S   S  S @
S      S @
S      S @
S      S @
P      P @
         @@
d s  b @
S  S S @
S   SS @
S    S @
S    S @
S    S @
P    P @
       @@
  sSSSs   @
 S     S  @
S       S @
S       S @
S       S @
 S     S  @
  "sss"   @
          @@
d ss.  @
S    b @
S    P @
S sS'  @
S      @
S      @
P      @
       @@
  sSSSs   @
 S     S  @
S       S @
S       S @
S       S @
 S   s S  @
  "sss"ss @
          @@
d ss.  @
S    b @
S    P @
S sS'  @
S   S  @
S    S @
P    P @
       @@
  sss. @
d      @
Y      @
  ss.  @
     b @
     P @
\` ss'  @
       @@
sss sssss @
    S     @
    S     @
    S     @
    S     @
    S     @
    P     @
          @@
d       b @
S       S @
S       S @
S       S @
S       S @
 S     S  @
  "sss"   @
          @@
d    b @
S    S @
S    S @
S    S @
S    S @
 S   S @
  "ssS @
       @@
d  d  b @
S  S  S @
S  S  S @
S  S  S @
S  S  S @
 S  S S @
  "ss"S @
        @@
Ss   sS @
  S S   @
   S    @
   S    @
   S    @
  S S   @
s"   "s @
        @@
Ss   sS @
  S S   @
   S    @
   S    @
   S    @
   S    @
   P    @
        @@
sSSSSSs @
     s  @
    s   @
   s    @
  s     @
 s      @
sSSSSSs @
        @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
d s.   @
S  ~O  @
S   \`b @
S sSSO @
S    O @
S    O @
P    P @
       @@
d ss.  @
S    b @
S    P @
S sSS' @
S    b @
S    P @
P \`SS  @
       @@
  sSSs. @
 S      @
S       @
S       @
S       @
 S      @
  "sss' @
        @@
d ss    @
S   ~o  @
S     b @
S     S @
S     P @
S    S  @
P ss"   @
        @@
d sss   @
S       @
S       @
S sSSs  @
S       @
S       @
P sSSss @
        @@
d sss  @
S      @
S      @
S sSSs @
S      @
S      @
P      @
       @@
  sSSSs   @
 S     S  @
S         @
S         @
S    ssSb @
 S     S  @
  "sss"   @
          @@
d    d @
S    S @
S    S @
S sSSS @
S    S @
S    S @
P    P @
       @@
d @
S @
S @
S @
S @
S @
P @
  @@
        d @
        S @
        S @
        S @
d       P @
 S     S  @
  "sss"   @
          @@
d     S @
S    P  @
Ssss'   @
S   s   @
S    b  @
S     b @
P     P @
        @@
d      @
S      @
S      @
S      @
S      @
S      @
P sSSs @
       @@
d s   sb @
S  S S S @
S   S  S @
S      S @
S      S @
S      S @
P      P @
         @@
d s  b @
S  S S @
S   SS @
S    S @
S    S @
S    S @
P    P @
       @@
  sSSSs   @
 S     S  @
S       S @
S       S @
S       S @
 S     S  @
  "sss"   @
          @@
d ss.  @
S    b @
S    P @
S sS'  @
S      @
S      @
P      @
       @@
  sSSSs   @
 S     S  @
S       S @
S       S @
S       S @
 S   s S  @
  "sss"ss @
          @@
d ss.  @
S    b @
S    P @
S sS'  @
S   S  @
S    S @
P    P @
       @@
  sss. @
d      @
Y      @
  ss.  @
     b @
     P @
\` ss'  @
       @@
sss sssss @
    S     @
    S     @
    S     @
    S     @
    S     @
    P     @
          @@
d       b @
S       S @
S       S @
S       S @
S       S @
 S     S  @
  "sss"   @
          @@
d    b @
S    S @
S    S @
S    S @
S    S @
 S   S @
  "ssS @
       @@
d  d  b @
S  S  S @
S  S  S @
S  S  S @
S  S  S @
 S  S S @
  "ss"S @
        @@
Ss   sS @
  S S   @
   S    @
   S    @
   S    @
  S S   @
s"   "s @
        @@
Ss   sS @
  S S   @
   S    @
   S    @
   S    @
   S    @
   P    @
        @@
sSSSSSs @
     s  @
    s   @
   s    @
  s     @
 s      @
sSSSSSs @
        @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
`