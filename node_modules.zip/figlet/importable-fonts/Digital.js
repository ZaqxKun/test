export default `flf2a 3 2 6 1 11 0 16513
Digital by Glenn Chappell 1/94 -- based on Bubble
Includes characters 128-255
Enhanced for Latin-2,3,4 by John Cowan <cowan@ccil.org>
Latin character sets supported only if your screen font does
figlet release 2.2 -- November 1996
Permission is hereby given to modify this font, as long as the
modifier's name is placed on a comment line.

Modified by Paul Burton <solution@earthlink.net> 12/96 to include new parameter
supported by FIGlet and FIGWin.  May also be slightly modified for better use
of new full-width/kern/smush alternatives, but default output is NOT changed.
 @
 @
 @@
 +-+@
 |!|@
 +-+@@
 +-+@
 |"|@
 +-+@@
 +-+@
 |#|@
 +-+@@
 +-+@
 |$|@
 +-+@@
 +-+@
 |%|@
 +-+@@
 +-+@
 |&|@
 +-+@@
 +-+@
 |'|@
 +-+@@
 +-+@
 |(|@
 +-+@@
 +-+@
 |)|@
 +-+@@
 +-+@
 |*|@
 +-+@@
 +-+@
 |+|@
 +-+@@
 +-+@
 |,|@
 +-+@@
 +-+@
 |-|@
 +-+@@
 +-+@
 |.|@
 +-+@@
 +-+@
 |/|@
 +-+@@
 +-+@
 |0|@
 +-+@@
 +-+@
 |1|@
 +-+@@
 +-+@
 |2|@
 +-+@@
 +-+@
 |3|@
 +-+@@
 +-+@
 |4|@
 +-+@@
 +-+@
 |5|@
 +-+@@
 +-+@
 |6|@
 +-+@@
 +-+@
 |7|@
 +-+@@
 +-+@
 |8|@
 +-+@@
 +-+@
 |9|@
 +-+@@
 +-+@
 |:|@
 +-+@@
 +-+@
 |;|@
 +-+@@
 +-+@
 |<|@
 +-+@@
 +-+@
 |=|@
 +-+@@
 +-+@
 |>|@
 +-+@@
 +-+@
 |?|@
 +-+@@
 +-+@
 |@|@
 +-+@@
 +-+@
 |A|@
 +-+@@
 +-+@
 |B|@
 +-+@@
 +-+@
 |C|@
 +-+@@
 +-+@
 |D|@
 +-+@@
 +-+@
 |E|@
 +-+@@
 +-+@
 |F|@
 +-+@@
 +-+@
 |G|@
 +-+@@
 +-+@
 |H|@
 +-+@@
 +-+@
 |I|@
 +-+@@
 +-+@
 |J|@
 +-+@@
 +-+@
 |K|@
 +-+@@
 +-+@
 |L|@
 +-+@@
 +-+@
 |M|@
 +-+@@
 +-+@
 |N|@
 +-+@@
 +-+@
 |O|@
 +-+@@
 +-+@
 |P|@
 +-+@@
 +-+@
 |Q|@
 +-+@@
 +-+@
 |R|@
 +-+@@
 +-+@
 |S|@
 +-+@@
 +-+@
 |T|@
 +-+@@
 +-+@
 |U|@
 +-+@@
 +-+@
 |V|@
 +-+@@
 +-+@
 |W|@
 +-+@@
 +-+@
 |X|@
 +-+@@
 +-+@
 |Y|@
 +-+@@
 +-+@
 |Z|@
 +-+@@
 +-+@
 |[|@
 +-+@@
 +-+@
 |\\|@
 +-+@@
 +-+@
 |]|@
 +-+@@
 +-+@
 |^|@
 +-+@@
 +-+@
 |_|@
 +-+@@
 +-+@
 |\`|@
 +-+@@
 +-+@
 |a|@
 +-+@@
 +-+@
 |b|@
 +-+@@
 +-+@
 |c|@
 +-+@@
 +-+@
 |d|@
 +-+@@
 +-+@
 |e|@
 +-+@@
 +-+@
 |f|@
 +-+@@
 +-+@
 |g|@
 +-+@@
 +-+@
 |h|@
 +-+@@
 +-+@
 |i|@
 +-+@@
 +-+@
 |j|@
 +-+@@
 +-+@
 |k|@
 +-+@@
 +-+@
 |l|@
 +-+@@
 +-+@
 |m|@
 +-+@@
 +-+@
 |n|@
 +-+@@
 +-+@
 |o|@
 +-+@@
 +-+@
 |p|@
 +-+@@
 +-+@
 |q|@
 +-+@@
 +-+@
 |r|@
 +-+@@
 +-+@
 |s|@
 +-+@@
 +-+@
 |t|@
 +-+@@
 +-+@
 |u|@
 +-+@@
 +-+@
 |v|@
 +-+@@
 +-+@
 |w|@
 +-+@@
 +-+@
 |x|@
 +-+@@
 +-+@
 |y|@
 +-+@@
 +-+@
 |z|@
 +-+@@
 +-+@
 |{|@
 +-+@@
 +-+@
 |||@
 +-+@@
 +-+@
 |}|@
 +-+@@
 +-+@
 |~|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
 +-+@
 |�|@
 +-+@@
128
 +-+@
 |�|@
 +-+@@
129
 +-+@
 |�|@
 +-+@@
130
 +-+@
 |�|@
 +-+@@
131
 +-+@
 |�|@
 +-+@@
132
 +-+@
 |�|@
 +-+@@
133
 +-+@
 |�|@
 +-+@@
134
 +-+@
 |�|@
 +-+@@
135
 +-+@
 |�|@
 +-+@@
136
 +-+@
 |�|@
 +-+@@
137
 +-+@
 |�|@
 +-+@@
138
 +-+@
 |�|@
 +-+@@
139
 +-+@
 |�|@
 +-+@@
140
 +-+@
 |�|@
 +-+@@
141
 +-+@
 |�|@
 +-+@@
142
 +-+@
 |�|@
 +-+@@
143
 +-+@
 |�|@
 +-+@@
144
 +-+@
 |�|@
 +-+@@
145
 +-+@
 |�|@
 +-+@@
146
 +-+@
 |�|@
 +-+@@
147
 +-+@
 |�|@
 +-+@@
148
 +-+@
 |�|@
 +-+@@
149
 +-+@
 |�|@
 +-+@@
150
 +-+@
 |�|@
 +-+@@
151
 +-+@
 |�|@
 +-+@@
152
 +-+@
 |�|@
 +-+@@
153
 +-+@
 |�|@
 +-+@@
154
 +-+@
 |�|@
 +-+@@
155
 +-+@
 |�|@
 +-+@@
156
 +-+@
 |�|@
 +-+@@
157
 +-+@
 |�|@
 +-+@@
158
 +-+@
 |�|@
 +-+@@
159
 +-+@
 |�|@
 +-+@@
160  NO-BREAK SPACE
 +-+@
 |�|@
 +-+@@
161  INVERTED EXCLAMATION MARK
 +-+@
 |�|@
 +-+@@
162  CENT SIGN
 +-+@
 |�|@
 +-+@@
163  POUND SIGN
 +-+@
 |�|@
 +-+@@
164  CURRENCY SIGN
 +-+@
 |�|@
 +-+@@
165  YEN SIGN
 +-+@
 |�|@
 +-+@@
166  BROKEN BAR
 +-+@
 |�|@
 +-+@@
167  SECTION SIGN
 +-+@
 |�|@
 +-+@@
168  DIAERESIS
 +-+@
 |�|@
 +-+@@
169  COPYRIGHT SIGN
 +-+@
 |�|@
 +-+@@
170  FEMININE ORDINAL INDICATOR
 +-+@
 |�|@
 +-+@@
171  LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
 +-+@
 |�|@
 +-+@@
172  NOT SIGN
 +-+@
 |�|@
 +-+@@
173  SOFT HYPHEN
 +-+@
 |�|@
 +-+@@
174  REGISTERED SIGN
 +-+@
 |�|@
 +-+@@
175  MACRON
 +-+@
 |�|@
 +-+@@
176  DEGREE SIGN
 +-+@
 |�|@
 +-+@@
177  PLUS-MINUS SIGN
 +-+@
 |�|@
 +-+@@
178  SUPERSCRIPT TWO
 +-+@
 |�|@
 +-+@@
179  SUPERSCRIPT THREE
 +-+@
 |�|@
 +-+@@
180  ACUTE ACCENT
 +-+@
 |�|@
 +-+@@
181  MICRO SIGN
 +-+@
 |�|@
 +-+@@
182  PILCROW SIGN
 +-+@
 |�|@
 +-+@@
183  MIDDLE DOT
 +-+@
 |�|@
 +-+@@
184  CEDILLA
 +-+@
 |�|@
 +-+@@
185  SUPERSCRIPT ONE
 +-+@
 |�|@
 +-+@@
186  MASCULINE ORDINAL INDICATOR
 +-+@
 |�|@
 +-+@@
187  RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK
 +-+@
 |�|@
 +-+@@
188  VULGAR FRACTION ONE QUARTER
 +-+@
 |�|@
 +-+@@
189  VULGAR FRACTION ONE HALF
 +-+@
 |�|@
 +-+@@
190  VULGAR FRACTION THREE QUARTERS
 +-+@
 |�|@
 +-+@@
191  INVERTED QUESTION MARK
 +-+@
 |�|@
 +-+@@
192  LATIN CAPITAL LETTER A WITH GRAVE
 +-+@
 |�|@
 +-+@@
193  LATIN CAPITAL LETTER A WITH ACUTE
 +-+@
 |�|@
 +-+@@
194  LATIN CAPITAL LETTER A WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
195  LATIN CAPITAL LETTER A WITH TILDE
 +-+@
 |�|@
 +-+@@
196  LATIN CAPITAL LETTER A WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
197  LATIN CAPITAL LETTER A WITH RING ABOVE
 +-+@
 |�|@
 +-+@@
198  LATIN CAPITAL LETTER AE
 +-+@
 |�|@
 +-+@@
199  LATIN CAPITAL LETTER C WITH CEDILLA
 +-+@
 |�|@
 +-+@@
200  LATIN CAPITAL LETTER E WITH GRAVE
 +-+@
 |�|@
 +-+@@
201  LATIN CAPITAL LETTER E WITH ACUTE
 +-+@
 |�|@
 +-+@@
202  LATIN CAPITAL LETTER E WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
203  LATIN CAPITAL LETTER E WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
204  LATIN CAPITAL LETTER I WITH GRAVE
 +-+@
 |�|@
 +-+@@
205  LATIN CAPITAL LETTER I WITH ACUTE
 +-+@
 |�|@
 +-+@@
206  LATIN CAPITAL LETTER I WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
207  LATIN CAPITAL LETTER I WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
208  LATIN CAPITAL LETTER ETH
 +-+@
 |�|@
 +-+@@
209  LATIN CAPITAL LETTER N WITH TILDE
 +-+@
 |�|@
 +-+@@
210  LATIN CAPITAL LETTER O WITH GRAVE
 +-+@
 |�|@
 +-+@@
211  LATIN CAPITAL LETTER O WITH ACUTE
 +-+@
 |�|@
 +-+@@
212  LATIN CAPITAL LETTER O WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
213  LATIN CAPITAL LETTER O WITH TILDE
 +-+@
 |�|@
 +-+@@
214  LATIN CAPITAL LETTER O WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
215  MULTIPLICATION SIGN
 +-+@
 |�|@
 +-+@@
216  LATIN CAPITAL LETTER O WITH STROKE
 +-+@
 |�|@
 +-+@@
217  LATIN CAPITAL LETTER U WITH GRAVE
 +-+@
 |�|@
 +-+@@
218  LATIN CAPITAL LETTER U WITH ACUTE
 +-+@
 |�|@
 +-+@@
219  LATIN CAPITAL LETTER U WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
220  LATIN CAPITAL LETTER U WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
221  LATIN CAPITAL LETTER Y WITH ACUTE
 +-+@
 |�|@
 +-+@@
222  LATIN CAPITAL LETTER THORN
 +-+@
 |�|@
 +-+@@
223  LATIN SMALL LETTER SHARP S
 +-+@
 |�|@
 +-+@@
224  LATIN SMALL LETTER A WITH GRAVE
 +-+@
 |�|@
 +-+@@
225  LATIN SMALL LETTER A WITH ACUTE
 +-+@
 |�|@
 +-+@@
226  LATIN SMALL LETTER A WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
227  LATIN SMALL LETTER A WITH TILDE
 +-+@
 |�|@
 +-+@@
228  LATIN SMALL LETTER A WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
229  LATIN SMALL LETTER A WITH RING ABOVE
 +-+@
 |�|@
 +-+@@
230  LATIN SMALL LETTER AE
 +-+@
 |�|@
 +-+@@
231  LATIN SMALL LETTER C WITH CEDILLA
 +-+@
 |�|@
 +-+@@
232  LATIN SMALL LETTER E WITH GRAVE
 +-+@
 |�|@
 +-+@@
233  LATIN SMALL LETTER E WITH ACUTE
 +-+@
 |�|@
 +-+@@
234  LATIN SMALL LETTER E WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
235  LATIN SMALL LETTER E WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
236  LATIN SMALL LETTER I WITH GRAVE
 +-+@
 |�|@
 +-+@@
237  LATIN SMALL LETTER I WITH ACUTE
 +-+@
 |�|@
 +-+@@
238  LATIN SMALL LETTER I WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
239  LATIN SMALL LETTER I WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
240  LATIN SMALL LETTER ETH
 +-+@
 |�|@
 +-+@@
241  LATIN SMALL LETTER N WITH TILDE
 +-+@
 |�|@
 +-+@@
242  LATIN SMALL LETTER O WITH GRAVE
 +-+@
 |�|@
 +-+@@
243  LATIN SMALL LETTER O WITH ACUTE
 +-+@
 |�|@
 +-+@@
244  LATIN SMALL LETTER O WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
245  LATIN SMALL LETTER O WITH TILDE
 +-+@
 |�|@
 +-+@@
246  LATIN SMALL LETTER O WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
247  DIVISION SIGN
 +-+@
 |�|@
 +-+@@
248  LATIN SMALL LETTER O WITH STROKE
 +-+@
 |�|@
 +-+@@
249  LATIN SMALL LETTER U WITH GRAVE
 +-+@
 |�|@
 +-+@@
250  LATIN SMALL LETTER U WITH ACUTE
 +-+@
 |�|@
 +-+@@
251  LATIN SMALL LETTER U WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
252  LATIN SMALL LETTER U WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
253  LATIN SMALL LETTER Y WITH ACUTE
 +-+@
 |�|@
 +-+@@
254  LATIN SMALL LETTER THORN
 +-+@
 |�|@
 +-+@@
255  LATIN SMALL LETTER Y WITH DIAERESIS
 +-+@
 |�|@
 +-+@@
0x0100  LATIN CAPITAL LETTER A WITH MACRON
 +-+@
 |�|@
 +-+@@
0x0101  LATIN SMALL LETTER A WITH MACRON
 +-+@
 |�|@
 +-+@@
0x0102  LATIN CAPITAL LETTER A WITH BREVE
 +-+@
 |�|@
 +-+@@
0x0103  LATIN SMALL LETTER A WITH BREVE
 +-+@
 |�|@
 +-+@@
0x0104  LATIN CAPITAL LETTER A WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0105  LATIN SMALL LETTER A WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0106  LATIN CAPITAL LETTER C WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0107  LATIN SMALL LETTER C WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0108  LATIN CAPITAL LETTER C WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x0109  LATIN SMALL LETTER C WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x010A  LATIN CAPITAL LETTER C WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x010B  LATIN SMALL LETTER C WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x010C  LATIN CAPITAL LETTER C WITH CARON
 +-+@
 |�|@
 +-+@@
0x010D  LATIN SMALL LETTER C WITH CARON
 +-+@
 |�|@
 +-+@@
0x010E  LATIN CAPITAL LETTER D WITH CARON
 +-+@
 |�|@
 +-+@@
0x010F  LATIN SMALL LETTER D WITH CARON
 +-+@
 |�|@
 +-+@@
0x0110  LATIN CAPITAL LETTER D WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0111  LATIN SMALL LETTER D WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0112  LATIN CAPITAL LETTER E WITH MACRON
 +-+@
 |�|@
 +-+@@
0x0113  LATIN SMALL LETTER E WITH MACRON
 +-+@
 |�|@
 +-+@@
0x0116  LATIN CAPITAL LETTER E WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x0117  LATIN SMALL LETTER E WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x0118  LATIN CAPITAL LETTER E WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0119  LATIN SMALL LETTER E WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x011A  LATIN CAPITAL LETTER E WITH CARON
 +-+@
 |�|@
 +-+@@
0x011B  LATIN SMALL LETTER E WITH CARON
 +-+@
 |�|@
 +-+@@
0x011C  LATIN CAPITAL LETTER G WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x011D  LATIN SMALL LETTER G WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x011E  LATIN CAPITAL LETTER G WITH BREVE
 +-+@
 |�|@
 +-+@@
0x011F  LATIN SMALL LETTER G WITH BREVE
 +-+@
 |�|@
 +-+@@
0x0120  LATIN CAPITAL LETTER G WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x0121  LATIN SMALL LETTER G WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x0122  LATIN CAPITAL LETTER G WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0123  LATIN SMALL LETTER G WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0124  LATIN CAPITAL LETTER H WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x0125  LATIN SMALL LETTER H WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x0126  LATIN CAPITAL LETTER H WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0127  LATIN SMALL LETTER H WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0128  LATIN CAPITAL LETTER I WITH TILDE
 +-+@
 |�|@
 +-+@@
0x0129  LATIN SMALL LETTER I WITH TILDE
 +-+@
 |�|@
 +-+@@
0x012A  LATIN CAPITAL LETTER I WITH MACRON
 +-+@
 |�|@
 +-+@@
0x012B  LATIN SMALL LETTER I WITH MACRON
 +-+@
 |�|@
 +-+@@
0x012E  LATIN CAPITAL LETTER I WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x012F  LATIN SMALL LETTER I WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0130  LATIN CAPITAL LETTER I WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x0131  LATIN SMALL LETTER DOTLESS I
 +-+@
 |�|@
 +-+@@
0x0134  LATIN CAPITAL LETTER J WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x0135  LATIN SMALL LETTER J WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x0136  LATIN CAPITAL LETTER K WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0137  LATIN SMALL LETTER K WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0138  LATIN SMALL LETTER KRA
 +-+@
 |�|@
 +-+@@
0x0139  LATIN CAPITAL LETTER L WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x013A  LATIN SMALL LETTER L WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x013B  LATIN CAPITAL LETTER L WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x013C  LATIN SMALL LETTER L WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x013D  LATIN CAPITAL LETTER L WITH CARON
 +-+@
 |�|@
 +-+@@
0x013E  LATIN SMALL LETTER L WITH CARON
 +-+@
 |�|@
 +-+@@
0x0141  LATIN CAPITAL LETTER L WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0142  LATIN SMALL LETTER L WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0143  LATIN CAPITAL LETTER N WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0144  LATIN SMALL LETTER N WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0145  LATIN CAPITAL LETTER N WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0146  LATIN SMALL LETTER N WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0147  LATIN CAPITAL LETTER N WITH CARON
 +-+@
 |�|@
 +-+@@
0x0148  LATIN SMALL LETTER N WITH CARON
 +-+@
 |�|@
 +-+@@
0x014A  LATIN CAPITAL LETTER ENG
 +-+@
 |�|@
 +-+@@
0x014B  LATIN SMALL LETTER ENG
 +-+@
 |�|@
 +-+@@
0x014C  LATIN CAPITAL LETTER O WITH MACRON
 +-+@
 |�|@
 +-+@@
0x014D  LATIN SMALL LETTER O WITH MACRON
 +-+@
 |�|@
 +-+@@
0x0150  LATIN CAPITAL LETTER O WITH DOUBLE ACUTE
 +-+@
 |�|@
 +-+@@
0x0151  LATIN SMALL LETTER O WITH DOUBLE ACUTE
 +-+@
 |�|@
 +-+@@
0x0154  LATIN CAPITAL LETTER R WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0155  LATIN SMALL LETTER R WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x0156  LATIN CAPITAL LETTER R WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0157  LATIN SMALL LETTER R WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0158  LATIN CAPITAL LETTER R WITH CARON
 +-+@
 |�|@
 +-+@@
0x0159  LATIN SMALL LETTER R WITH CARON
 +-+@
 |�|@
 +-+@@
0x015A  LATIN CAPITAL LETTER S WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x015B  LATIN SMALL LETTER S WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x015C  LATIN CAPITAL LETTER S WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x015D  LATIN SMALL LETTER S WITH CIRCUMFLEX
 +-+@
 |�|@
 +-+@@
0x015E  LATIN CAPITAL LETTER S WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x015F  LATIN SMALL LETTER S WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0160  LATIN CAPITAL LETTER S WITH CARON
 +-+@
 |�|@
 +-+@@
0x0161  LATIN SMALL LETTER S WITH CARON
 +-+@
 |�|@
 +-+@@
0x0162  LATIN CAPITAL LETTER T WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0163  LATIN SMALL LETTER T WITH CEDILLA
 +-+@
 |�|@
 +-+@@
0x0164  LATIN CAPITAL LETTER T WITH CARON
 +-+@
 |�|@
 +-+@@
0x0165  LATIN SMALL LETTER T WITH CARON
 +-+@
 |�|@
 +-+@@
0x0166  LATIN CAPITAL LETTER T WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0167  LATIN SMALL LETTER T WITH STROKE
 +-+@
 |�|@
 +-+@@
0x0168  LATIN CAPITAL LETTER U WITH TILDE
 +-+@
 |�|@
 +-+@@
0x0169  LATIN SMALL LETTER U WITH TILDE
 +-+@
 |�|@
 +-+@@
0x016A  LATIN CAPITAL LETTER U WITH MACRON
 +-+@
 |�|@
 +-+@@
0x016B  LATIN SMALL LETTER U WITH MACRON
 +-+@
 |�|@
 +-+@@
0x016C  LATIN CAPITAL LETTER U WITH BREVE
 +-+@
 |�|@
 +-+@@
0x016D  LATIN SMALL LETTER U WITH BREVE
 +-+@
 |�|@
 +-+@@
0x016E  LATIN CAPITAL LETTER U WITH RING ABOVE
 +-+@
 |�|@
 +-+@@
0x016F  LATIN SMALL LETTER U WITH RING ABOVE
 +-+@
 |�|@
 +-+@@
0x0170  LATIN CAPITAL LETTER U WITH DOUBLE ACUTE
 +-+@
 |�|@
 +-+@@
0x0171  LATIN SMALL LETTER U WITH DOUBLE ACUTE
 +-+@
 |�|@
 +-+@@
0x0172  LATIN CAPITAL LETTER U WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0173  LATIN SMALL LETTER U WITH OGONEK
 +-+@
 |�|@
 +-+@@
0x0179  LATIN CAPITAL LETTER Z WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x017A  LATIN SMALL LETTER Z WITH ACUTE
 +-+@
 |�|@
 +-+@@
0x017B  LATIN CAPITAL LETTER Z WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x017C  LATIN SMALL LETTER Z WITH DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x017D  LATIN CAPITAL LETTER Z WITH CARON
 +-+@
 |�|@
 +-+@@
0x017E  LATIN SMALL LETTER Z WITH CARON
 +-+@
 |�|@
 +-+@@
0x02C7  CARON
 +-+@
 |�|@
 +-+@@
0x02D8  BREVE
 +-+@
 |�|@
 +-+@@
0x02D9  DOT ABOVE
 +-+@
 |�|@
 +-+@@
0x02DB  OGONEK
 +-+@
 |�|@
 +-+@@
0x02DD  DOUBLE ACUTE ACCENT
 +-+@
 |�|@
 +-+@@
`